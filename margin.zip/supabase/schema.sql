-- Margin database schema for Supabase (Postgres).
-- Run this in the Supabase SQL editor once the project is created.
-- Tables mirror the types in src/lib/data.ts.

create table profiles (
  id uuid primary key references auth.users on delete cascade,
  username text unique not null check (username ~ '^[a-z0-9._]{3,30}$'),
  name text not null,
  school text,
  bio text,
  verified boolean not null default false,
  stripe_account_id text,            -- Stripe Connect account for payouts
  created_at timestamptz not null default now()
);

create type guide_kind as enum ('Study guide', 'Cheat sheet', 'Practice set', 'Anki deck');
create type guide_status as enum ('pending_review', 'live', 'removed');

create table guides (
  id bigint generated always as identity primary key,
  seller_id uuid not null references profiles on delete cascade,
  course text not null,
  title text not null,
  kind guide_kind not null,
  subject text not null,
  pages int not null check (pages > 0),
  price_cents int not null check (price_cents >= 100),
  caption text,
  contents text[] not null default '{}',
  file_path text not null,           -- path in the private "guides" storage bucket
  preview_path text,                 -- free preview page shown before purchase
  original_attested boolean not null check (original_attested),
  status guide_status not null default 'pending_review',
  created_at timestamptz not null default now()
);

create table purchases (
  id bigint generated always as identity primary key,
  guide_id bigint not null references guides,
  buyer_id uuid not null references profiles,
  amount_cents int not null,
  stripe_payment_intent text unique,
  refunded boolean not null default false,
  created_at timestamptz not null default now(),
  unique (guide_id, buyer_id)
);

create type offering_category as enum ('tutoring', 'advising', 'piq');

create table offerings (
  id bigint generated always as identity primary key,
  provider_id uuid not null references profiles on delete cascade,
  category offering_category not null,
  topics text not null,
  location text not null,
  name text not null,
  minutes int not null check (minutes > 0),
  price_cents int not null check (price_cents >= 0)
);

-- Weekly open hours, e.g. Tuesdays 15:00–18:00 Pacific.
create table availability (
  id bigint generated always as identity primary key,
  provider_id uuid not null references profiles on delete cascade,
  weekday int not null check (weekday between 0 and 6),
  starts time not null,
  ends time not null,
  timezone text not null default 'America/Los_Angeles'
);

create table bookings (
  id bigint generated always as identity primary key,
  offering_id bigint not null references offerings,
  provider_id uuid not null references profiles,
  client_id uuid not null references profiles,
  starts_at timestamptz not null,
  ends_at timestamptz not null,
  status text not null default 'confirmed' check (status in ('confirmed', 'cancelled', 'completed')),
  stripe_payment_intent text,
  created_at timestamptz not null default now()
);
-- A provider can't be double-booked for the same start time.
create unique index bookings_no_double on bookings (provider_id, starts_at) where status = 'confirmed';

create table reviews (
  id bigint generated always as identity primary key,
  author_id uuid not null references profiles,
  subject_id uuid not null references profiles,
  guide_id bigint references guides,
  booking_id bigint references bookings,
  stars int not null check (stars between 1 and 5),
  body text,
  created_at timestamptz not null default now()
);

create table likes (
  guide_id bigint references guides on delete cascade,
  user_id uuid references profiles on delete cascade,
  primary key (guide_id, user_id)
);

create table reports (
  id bigint generated always as identity primary key,
  guide_id bigint not null references guides,
  reporter_id uuid references profiles,
  reason text not null,              -- e.g. 'lecture_notes', 'copied', 'spam'
  created_at timestamptz not null default now()
);

-- Row level security: everyone reads public data, people only write their own rows.
alter table profiles enable row level security;
alter table guides enable row level security;
alter table purchases enable row level security;
alter table offerings enable row level security;
alter table availability enable row level security;
alter table bookings enable row level security;
alter table reviews enable row level security;
alter table likes enable row level security;
alter table reports enable row level security;

create policy "profiles are public" on profiles for select using (true);
create policy "edit own profile" on profiles for update using (auth.uid() = id);
create policy "create own profile" on profiles for insert with check (auth.uid() = id);

create policy "live guides are public" on guides for select using (status = 'live' or seller_id = auth.uid());
create policy "sellers post guides" on guides for insert with check (seller_id = auth.uid() and status = 'pending_review');
create policy "sellers edit own guides" on guides for update using (seller_id = auth.uid());

-- Purchases and paid bookings are written by the Stripe webhook using the service role, not by clients.
create policy "see own purchases" on purchases for select using (buyer_id = auth.uid());

create policy "offerings are public" on offerings for select using (true);
create policy "manage own offerings" on offerings for all using (provider_id = auth.uid()) with check (provider_id = auth.uid());
create policy "availability is public" on availability for select using (true);
create policy "manage own availability" on availability for all using (provider_id = auth.uid()) with check (provider_id = auth.uid());

create policy "see own bookings" on bookings for select using (client_id = auth.uid() or provider_id = auth.uid());
create policy "book free sessions" on bookings for insert with check (client_id = auth.uid());
create policy "cancel own bookings" on bookings for update using (client_id = auth.uid() or provider_id = auth.uid());

create policy "reviews are public" on reviews for select using (true);
create policy "write own reviews" on reviews for insert with check (author_id = auth.uid());

create policy "likes are public" on likes for select using (true);
create policy "like as yourself" on likes for insert with check (user_id = auth.uid());
create policy "unlike as yourself" on likes for delete using (user_id = auth.uid());

create policy "anyone signed in can report" on reports for insert with check (auth.uid() is not null);

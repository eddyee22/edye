import Link from "next/link";
import { avatarColors, getProfile, initials, money, compact, subjectGradient, type Guide } from "@/lib/data";

export function Avatar({ username, size = 32, ring = false }: { username: string; size?: number; ring?: boolean }) {
  const p = getProfile(username);
  const av = (
    <div
      className="av"
      style={{ width: size, height: size, fontSize: size * 0.34, background: avatarColors[p?.color ?? 0] }}
    >
      {p ? initials(p.name) : "?"}
    </div>
  );
  return ring ? <div className="ring">{av}</div> : av;
}

export function Verified() {
  return (
    <svg width="13" height="13" viewBox="0 0 24 24" style={{ display: "inline", verticalAlign: -2, marginLeft: 3 }} aria-label="Verified">
      <circle cx="12" cy="12" r="11" fill="#3897f0" />
      <path d="m7 12.5 3.2 3.2L17 9" fill="none" stroke="#fff" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function Cover({ guide, small = false }: { guide: Guide; small?: boolean }) {
  const unit = guide.kind === "Anki deck" ? "cards" : "pages";
  return (
    <div className={`cover${small ? " small" : ""}`} style={{ background: subjectGradient[guide.subject] }}>
      <div className="price">{money(guide.priceCents)}</div>
      <div className="code">{guide.course}</div>
      <div>
        <div className="ttl">{guide.title}</div>
        {!small && (
          <div className="meta">
            <span>{guide.kind}</span>
            <span>{guide.pages} {unit}</span>
            <span>{compact(guide.sold)} sold</span>
          </div>
        )}
      </div>
    </div>
  );
}

export function GuideGrid({ items }: { items: Guide[] }) {
  return (
    <div className="grid">
      {items.map((g) => (
        <Link key={g.id} href={`/guides/${g.id}`} aria-label={g.title}>
          <Cover guide={g} small />
        </Link>
      ))}
    </div>
  );
}

export function TopBar({ title, children }: { title: React.ReactNode; children?: React.ReactNode }) {
  return (
    <header className="top">
      <h1>{title}</h1>
      <div className="icons">{children}</div>
    </header>
  );
}

const paths = {
  home: <path d="M3 10.5 12 3l9 7.5V21h-6v-6H9v6H3z" />,
  search: (<><circle cx="11" cy="11" r="7" /><path d="m20 20-3.5-3.5" /></>),
  plus: (<><rect x="3" y="3" width="18" height="18" rx="5" /><path d="M12 8v8M8 12h8" /></>),
  cal: (<><rect x="3" y="4.5" width="18" height="16.5" rx="3" /><path d="M3 9.5h18M8 2.5v4M16 2.5v4" /></>),
  heart: <path d="M12 20.5s-8-4.7-8-10.6A4.4 4.4 0 0 1 12 7a4.4 4.4 0 0 1 8 2.9c0 5.9-8 10.6-8 10.6z" />,
  chat: <path d="M20.5 11.5a8.5 8.5 0 0 1-12.6 7.4L3.5 20.5l1.6-4.3A8.5 8.5 0 1 1 20.5 11.5z" />,
  send: <path d="M21.5 3 10 14.5M21.5 3l-7 18-4.5-6.5L3 10z" />,
  save: <path d="M6 3h12v18l-6-5-6 5z" />,
  grid: (<><rect x="3" y="3" width="18" height="18" rx="2" /><path d="M9 3v18M15 3v18M3 9h18M3 15h18" /></>),
  star: <path d="m12 3 2.8 5.8 6.2.9-4.5 4.4 1 6.3L12 17.5 6.5 20.4l1-6.3L3 9.7l6.2-.9z" />,
  back: <path d="M15 5 8 12l7 7" />,
};

export function Icon({ name, size = 24 }: { name: keyof typeof paths; size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      {paths[name]}
    </svg>
  );
}

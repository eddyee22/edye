"use client";

import Link from "next/link";
import { CURRENT_USER, getProfile, money, timeAgo, type Guide } from "@/lib/data";
import { useStore } from "@/lib/store";
import { Avatar, Cover, Icon, Verified } from "./ui";

export default function PostCard({ guide }: { guide: Guide }) {
  const { liked, saved, purchased, toggle } = useStore();
  const p = getProfile(guide.seller)!;
  const isLiked = liked.includes(guide.id);
  const isSaved = saved.includes(guide.id);
  const own = guide.seller === CURRENT_USER;

  return (
    <article className="post">
      <div className="post-h">
        <Link href={`/u/${p.username}`}><Avatar username={p.username} /></Link>
        <div className="who">
          <Link href={`/u/${p.username}`}><b>{p.username}</b></Link>
          {p.verified && <Verified />}
          <small>{p.school.split(" · ")[0]} · {guide.course}</small>
        </div>
      </div>
      <Link href={`/guides/${guide.id}`} onDoubleClick={(e) => { e.preventDefault(); if (!isLiked) toggle("liked", guide.id); }}>
        <Cover guide={guide} />
      </Link>
      <div className="actions">
        <button className={isLiked ? "liked" : ""} onClick={() => toggle("liked", guide.id)} aria-label="Like" aria-pressed={isLiked}><Icon name="heart" size={25} /></button>
        <Link href={`/guides/${guide.id}`} aria-label="Comments"><Icon name="chat" /></Link>
        <button aria-label="Share" onClick={() => navigator.clipboard?.writeText(`${location.origin}/guides/${guide.id}`).catch(() => {})}><Icon name="send" /></button>
        <span className="sp" />
        <button className={isSaved ? "saved" : ""} onClick={() => toggle("saved", guide.id)} aria-label="Save" aria-pressed={isSaved}><Icon name="save" /></button>
      </div>
      <div className="buybar">
        <div className="t"><b>{guide.title}</b><small>{guide.kind} · instant download</small></div>
        {own ? <span className="btn ghost">Your guide</span>
          : purchased.includes(guide.id) ? <span className="btn done">Owned</span>
          : <Link className="btn" href={`/guides/${guide.id}`}>Buy {money(guide.priceCents)}</Link>}
      </div>
      <div className="likes">{(guide.likes + (isLiked ? 1 : 0)).toLocaleString()} likes</div>
      {guide.caption && <div className="cap"><b>{p.username}</b> {guide.caption} <span className="tag">{guide.tags}</span></div>}
      <div className="when" suppressHydrationWarning>{timeAgo(guide.postedAt)}</div>
    </article>
  );
}

"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Avatar, Icon } from "./ui";
import { CURRENT_USER } from "@/lib/data";

export default function TabBar() {
  const path = usePathname();
  const on = (p: string) => (p === "/" ? path === "/" : path.startsWith(p)) ? "on" : "";
  return (
    <nav className="tabbar">
      <Link href="/" className={on("/")} aria-label="Home"><Icon name="home" size={26} /></Link>
      <Link href="/explore" className={on("/explore")} aria-label="Explore"><Icon name="search" size={26} /></Link>
      <Link href="/create" className={on("/create")} aria-label="Create"><Icon name="plus" size={26} /></Link>
      <Link href="/sessions" className={on("/sessions")} aria-label="Sessions"><Icon name="cal" size={26} /></Link>
      <Link href={`/u/${CURRENT_USER}`} className={on(`/u/${CURRENT_USER}`)} aria-label="Profile"><Avatar username={CURRENT_USER} size={26} /></Link>
    </nav>
  );
}

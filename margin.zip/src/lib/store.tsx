"use client";

// Per-device state (likes, saves, purchases, bookings, posted guides) kept in localStorage.
// This stands in for the Supabase tables until the backend is connected.

import { createContext, useContext, useEffect, useState } from "react";
import type { Guide } from "./data";

export type Booking = {
  id: string;
  provider: string;
  session: string;
  startsAt: string; // ISO
  where: string;
  priceCents: number;
};

type State = {
  liked: number[];
  saved: number[];
  purchased: number[];
  bookings: Booking[];
  myGuides: Guide[];
};

const initial: State = { liked: [], saved: [], purchased: [], bookings: [], myGuides: [] };
const KEY = "margin.v1";

type Ctx = State & {
  toggle: (list: "liked" | "saved", id: number) => void;
  purchase: (id: number) => void;
  book: (b: Omit<Booking, "id">) => void;
  postGuide: (g: Guide) => void;
};

const StoreContext = createContext<Ctx | null>(null);

export function StoreProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<State>(initial);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) setState({ ...initial, ...JSON.parse(raw) });
    } catch {}
  }, []);

  const update = (fn: (s: State) => State) =>
    setState((s) => {
      const next = fn(s);
      try {
        localStorage.setItem(KEY, JSON.stringify(next));
      } catch {}
      return next;
    });

  const value: Ctx = {
    ...state,
    toggle: (list, id) =>
      update((s) => ({ ...s, [list]: s[list].includes(id) ? s[list].filter((x) => x !== id) : [...s[list], id] })),
    purchase: (id) => update((s) => ({ ...s, purchased: [...new Set([...s.purchased, id])] })),
    book: (b) =>
      update((s) => ({
        ...s,
        bookings: [...s.bookings, { ...b, id: crypto.randomUUID() }].sort((a, c) => a.startsAt.localeCompare(c.startsAt)),
      })),
    postGuide: (g) => update((s) => ({ ...s, myGuides: [g, ...s.myGuides] })),
  };

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useStore() {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error("useStore must be used inside StoreProvider");
  return ctx;
}

// Sample data used until the app is connected to Supabase (see supabase/schema.sql).
// The shapes here mirror the database tables so swapping the source is a small change.

export type Subject = "cs" | "math" | "bio" | "chem" | "econ" | "hist" | "piq" | "psych" | "adv";

export type Profile = {
  username: string;
  name: string;
  school: string;
  bio: string;
  color: number;
  verified?: boolean;
};

export type Guide = {
  id: number;
  seller: string;
  course: string;
  title: string;
  kind: "Study guide" | "Cheat sheet" | "Practice set" | "Anki deck";
  pages: number;
  priceCents: number;
  subject: Subject;
  likes: number;
  sold: number;
  caption?: string;
  tags?: string;
  postedAt: string;
  contents: string[];
};

export type OfferingCategory = "tutoring" | "advising" | "piq";

export type Offering = {
  provider: string;
  category: OfferingCategory;
  topics: string;
  where: string;
  rating: number;
  reviews: number;
  sessions: { name: string; minutes: number; priceCents: number }[];
};

export type Review = { author: string; subject: string; stars: number; text: string };

export const CURRENT_USER = "tina.studies";

export const subjectGradient: Record<Subject, string> = {
  cs: "linear-gradient(140deg,#3a47ff,#7b2ff7)",
  math: "linear-gradient(140deg,#ff6a3d,#ff2d78)",
  bio: "linear-gradient(140deg,#0f9b6c,#3bc4a0)",
  chem: "linear-gradient(140deg,#00a3ff,#3d5afe)",
  econ: "linear-gradient(140deg,#f7b733,#fc4a1a)",
  hist: "linear-gradient(140deg,#8e4c2f,#c9733e)",
  piq: "linear-gradient(140deg,#c13ad8,#ff4f6d)",
  psych: "linear-gradient(140deg,#5f2c82,#49a09d)",
  adv: "linear-gradient(140deg,#1d2b64,#6a4cff)",
};

export const avatarColors = ["#ff4f6d", "#6a4cff", "#0f9b6c", "#ff8a00", "#00a3ff", "#c13ad8", "#e0446a", "#2b8a6e"];

export const profiles: Profile[] = [
  { username: "tina.studies", name: "Tina Y.", school: "UC Berkeley · Cognitive Science '28", color: 5, bio: "Turning my notes into guides so you don't have to. Tutoring COGSCI 1 & DATA C8 on weekends." },
  { username: "maya.codes", name: "Maya Chen", school: "UC Berkeley · EECS '27", color: 1, verified: true, bio: "CS 61A/61B tutor. 3 semesters as a lab assistant." },
  { username: "jreyes.math", name: "Jordan Reyes", school: "UCLA · Applied Math '27", color: 3, verified: true, bio: "Math is just patterns. I'll show you the patterns." },
  { username: "priya.piq", name: "Priya Natarajan", school: "UC Berkeley · English '26", color: 0, verified: true, bio: "PIQ coach. Helped 60+ students get into UCs." },
  { username: "leo.bio", name: "Leo Park", school: "UC Davis · Neurobiology '27", color: 2, bio: "Bio and orgo, drawn out as maps." },
  { username: "sam.econ", name: "Sam Okafor", school: "UCLA · Economics '26", color: 4, bio: "Econ graphs from memory, guaranteed." },
  { username: "ava.writes", name: "Ava Lin", school: "UCSD · Literature '27", color: 6, bio: "PIQ topic picking and line edits." },
  { username: "advising.ruiz", name: "Dr. Dana Ruiz", school: "L&S Advising", color: 7, verified: true, bio: "Course planning and major declaration." },
  { username: "kai.transfer", name: "Kai Thompson", school: "Transfer advisor · SMC → UCLA", color: 1, bio: "TAG, IGETC and transfer timelines." },
];

export const guides: Guide[] = [
  { id: 1, seller: "maya.codes", course: "CS 61A", title: "Recursion & Trees, Midterm 2", kind: "Study guide", pages: 28, priceCents: 900, subject: "cs", likes: 1284, sold: 212, caption: "Every recursion pattern from the last 6 midterms, worked out step by step.", tags: "#cs61a #berkeley", postedAt: "2026-10-14T22:00:00Z", contents: ["Tree recursion templates", "Linked lists & mutation", "12 practice problems, solved"] },
  { id: 2, seller: "jreyes.math", course: "MATH 31B", title: "Series Convergence Cheat Sheet", kind: "Cheat sheet", pages: 6, priceCents: 400, subject: "math", likes: 842, sold: 390, caption: "All 9 convergence tests on one page plus a flowchart for picking which one.", tags: "#math31b #ucla", postedAt: "2026-10-14T19:00:00Z", contents: ["Test-picking flowchart", "Ratio vs root, when each wins", "20 practice series"] },
  { id: 3, seller: "priya.piq", course: "UC PIQ", title: "PIQ #1 Leadership: 5 Real Drafts", kind: "Study guide", pages: 18, priceCents: 1200, subject: "piq", likes: 2310, sold: 540, caption: "Before and after drafts from students who got into Berkeley and UCLA.", tags: "#piq #ucapp", postedAt: "2026-10-13T18:00:00Z", contents: ["What readers look for", "5 drafts with margin notes", "Cutting 500 words to 350"] },
  { id: 4, seller: "leo.bio", course: "BIS 2A", title: "Cellular Respiration, Fully Mapped", kind: "Study guide", pages: 14, priceCents: 600, subject: "bio", likes: 611, sold: 144, caption: "Glycolysis to ETC on one color-coded map.", tags: "#bis2a #ucdavis", postedAt: "2026-10-13T16:00:00Z", contents: ["One-page pathway map", "ATP accounting table", "Practice MCQs"] },
  { id: 5, seller: "sam.econ", course: "ECON 1", title: "Elasticity & Market Structures", kind: "Practice set", pages: 22, priceCents: 700, subject: "econ", likes: 503, sold: 98, caption: "Graphs you need to draw from memory, with the shift rules spelled out.", tags: "#econ1", postedAt: "2026-10-12T16:00:00Z", contents: ["12 must-know graphs", "Shift rules", "Final review problems"] },
  { id: 6, seller: "tina.studies", course: "COGSCI 1", title: "Intro Cog Sci Final Review", kind: "Study guide", pages: 31, priceCents: 800, subject: "psych", likes: 377, sold: 61, caption: "Every topic condensed, plus the key studies with dates.", tags: "#cogsci1", postedAt: "2026-10-11T16:00:00Z", contents: ["Topic-by-topic summary", "Key studies timeline", "Essay practice prompts"] },
  { id: 7, seller: "tina.studies", course: "PSYCH C61", title: "Brain Regions Flashcards", kind: "Anki deck", pages: 240, priceCents: 500, subject: "chem", likes: 290, sold: 84, postedAt: "2026-10-01T16:00:00Z", contents: ["240 cards", "Labeled diagrams", "Function → region drills"] },
  { id: 8, seller: "tina.studies", course: "DATA C8", title: "Tables Quick Reference", kind: "Cheat sheet", pages: 8, priceCents: 400, subject: "cs", likes: 198, sold: 47, postedAt: "2026-09-20T16:00:00Z", contents: ["Every Table method", "Common errors", "Practice questions"] },
  { id: 9, seller: "ava.writes", course: "UC PIQ", title: "Picking Your 4 PIQs", kind: "Study guide", pages: 9, priceCents: 500, subject: "piq", likes: 980, sold: 260, postedAt: "2026-10-05T16:00:00Z", contents: ["All 8 prompts decoded", "Topic-matching worksheet", "Example pairings"] },
  { id: 10, seller: "jreyes.math", course: "MATH 33A", title: "Linear Algebra Proof Patterns", kind: "Study guide", pages: 20, priceCents: 800, subject: "math", likes: 410, sold: 120, postedAt: "2026-10-02T16:00:00Z", contents: ["Proof templates", "Span & basis", "Eigenvalue tricks"] },
  { id: 11, seller: "maya.codes", course: "CS 61B", title: "Data Structures Runtime Table", kind: "Cheat sheet", pages: 4, priceCents: 300, subject: "cs", likes: 1502, sold: 610, postedAt: "2026-09-28T16:00:00Z", contents: ["Big-O for every structure", "When to use which", "Practice questions"] },
];

const s = (name: string, minutes: number, dollars: number) => ({ name, minutes, priceCents: dollars * 100 });

export const offerings: Offering[] = [
  { provider: "maya.codes", category: "tutoring", topics: "CS 61A, CS 61B, Python", where: "Zoom or Moffitt Library", rating: 4.9, reviews: 128, sessions: [s("Single session", 60, 35), s("Exam cram", 90, 49), s("Homework check-in", 30, 19)] },
  { provider: "jreyes.math", category: "tutoring", topics: "Calc, Linear Algebra, Stats", where: "Zoom", rating: 4.8, reviews: 96, sessions: [s("Single session", 60, 30), s("Exam cram", 90, 42)] },
  { provider: "leo.bio", category: "tutoring", topics: "Bio, Organic Chem", where: "Zoom", rating: 4.7, reviews: 54, sessions: [s("Single session", 60, 28)] },
  { provider: "sam.econ", category: "tutoring", topics: "Micro & Macro Econ", where: "Zoom", rating: 4.8, reviews: 41, sessions: [s("Single session", 60, 25)] },
  { provider: "tina.studies", category: "tutoring", topics: "COGSCI 1, DATA C8", where: "Zoom", rating: 4.9, reviews: 22, sessions: [s("Single session", 60, 30)] },
  { provider: "advising.ruiz", category: "advising", topics: "Major declaration, course planning", where: "Evans Hall, 2nd floor", rating: 5.0, reviews: 312, sessions: [s("Course planning", 30, 0), s("Major declaration", 45, 0)] },
  { provider: "kai.transfer", category: "advising", topics: "CC transfer, TAG, IGETC", where: "Zoom", rating: 4.9, reviews: 87, sessions: [s("Transfer plan", 30, 20)] },
  { provider: "priya.piq", category: "piq", topics: "All 8 PIQs, brainstorm to final", where: "Zoom + shared Google Doc", rating: 5.0, reviews: 203, sessions: [s("Brainstorm", 60, 45), s("Draft review", 60, 45), s("Full package, 4 PIQs", 240, 160)] },
  { provider: "ava.writes", category: "piq", topics: "PIQ topic picking, line edits", where: "Zoom", rating: 4.9, reviews: 118, sessions: [s("Topic picking", 60, 40), s("Line edit", 60, 40)] },
];

export const reviews: Review[] = [
  { author: "leo.bio", subject: "tina.studies", stars: 5, text: "Tina's Cog Sci review was better than anything else I found. Bought it the night before and still passed." },
  { author: "sam.econ", subject: "tina.studies", stars: 5, text: "Booked a 1:1 to go over the essay prompts. Super patient." },
  { author: "jreyes.math", subject: "tina.studies", stars: 4, text: "Great flashcards. Wish there were a few more practice questions." },
];

export const getProfile = (username: string) => profiles.find((p) => p.username === username);
export const getGuide = (id: number) => guides.find((g) => g.id === id);
export const guidesBy = (username: string) => guides.filter((g) => g.seller === username);
export const offeringsBy = (username: string) => offerings.filter((o) => o.provider === username);
export const reviewsFor = (username: string) => reviews.filter((r) => r.subject === username);

export const money = (cents: number) => (cents === 0 ? "Free" : `$${(cents / 100).toFixed(cents % 100 ? 2 : 0)}`);
export const compact = (n: number) => (n >= 1000 ? `${(n / 1000).toFixed(1).replace(".0", "")}K` : String(n));
export const initials = (name: string) =>
  name.replace("Dr. ", "").split(" ").map((w) => w[0]).join("").slice(0, 2);

export function timeAgo(iso: string, now = new Date()) {
  const h = Math.floor((now.getTime() - new Date(iso).getTime()) / 3_600_000);
  if (h < 1) return "Just now";
  if (h < 24) return `${h} hour${h === 1 ? "" : "s"} ago`;
  const d = Math.floor(h / 24);
  return d === 1 ? "Yesterday" : `${d} days ago`;
}

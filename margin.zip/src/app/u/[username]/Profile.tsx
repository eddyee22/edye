"use client";

import Link from "next/link";
import { useState } from "react";
import { Avatar, GuideGrid, Icon, TopBar, Verified } from "@/components/ui";
import { CURRENT_USER, compact, getProfile, guidesBy, money, offeringsBy, reviewsFor } from "@/lib/data";
import { useStore } from "@/lib/store";

export default function Profile({ username }: { username: string }) {
  const p = getProfile(username)!;
  const isMe = username === CURRENT_USER;
  const { myGuides } = useStore();
  const [tab, setTab] = useState<"guides" | "reviews">("guides");

  const items = [...(isMe ? myGuides : []), ...guidesBy(username)];
  const offers = offeringsBy(username);
  const revs = reviewsFor(username);
  const sold = items.reduce((n, g) => n + g.sold, 0);
  const from = offers.length ? Math.min(...offers.flatMap((o) => o.sessions.map((s) => s.priceCents))) : null;

  return (
    <>
      <TopBar title={<>{p.username}{p.verified && <Verified />}</>}>
        {isMe ? <Link href="/create" aria-label="Create"><Icon name="plus" /></Link> : <Link href="/" aria-label="Back"><Icon name="back" /></Link>}
      </TopBar>
      <section style={{ padding: "6px 14px 0" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 20 }}>
          <Avatar username={username} size={84} ring />
          <div className="stats">
            <div><b>{items.length}</b><span>guides</span></div>
            <div><b>{compact(sold)}</b><span>sold</span></div>
            <div><b>{offers.reduce((n, o) => n + o.reviews, 0)}</b><span>reviews</span></div>
          </div>
        </div>
        <div style={{ fontSize: 13.5, lineHeight: 1.4, padding: "10px 0" }}>
          <b style={{ display: "block" }}>{p.name}</b>
          <span style={{ color: "var(--muted)" }}>{p.school}</span>
          <div>{p.bio}</div>
          {from !== null && <span className="pill">Sessions from {money(from)}</span>}
          {offers[0] && <span className="pill">★ {offers[0].rating.toFixed(1)}</span>}
        </div>
        <div style={{ display: "flex", gap: 6 }}>
          {isMe ? (
            <>
              <Link className="btn ghost" style={{ flex: 1 }} href="/create">Sell a guide</Link>
              <Link className="btn ghost" style={{ flex: 1 }} href="/sessions">My sessions</Link>
            </>
          ) : (
            <>
              <button className="btn" style={{ flex: 1 }}>Follow</button>
              {offers.length > 0 && <Link className="btn ghost" style={{ flex: 1 }} href={`/book/${username}`}>Book 1:1</Link>}
            </>
          )}
        </div>
      </section>
      <div className="ptabs">
        <button className={tab === "guides" ? "on" : ""} onClick={() => setTab("guides")} aria-label="Guides"><Icon name="grid" size={22} /></button>
        <button className={tab === "reviews" ? "on" : ""} onClick={() => setTab("reviews")} aria-label="Reviews"><Icon name="star" size={22} /></button>
      </div>
      {tab === "guides" ? (
        items.length ? <GuideGrid items={items} /> : <div className="empty">No guides yet.</div>
      ) : revs.length ? (
        revs.map((r, i) => (
          <div key={i} style={{ padding: "12px 14px", borderBottom: "1px solid var(--line)", fontSize: 13.5, lineHeight: 1.4 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4 }}>
              <Avatar username={r.author} size={24} /><b>{r.author}</b><span className="stars">{"★".repeat(r.stars)}</span>
            </div>
            {r.text}
          </div>
        ))
      ) : <div className="empty">No reviews yet.</div>}
    </>
  );
}

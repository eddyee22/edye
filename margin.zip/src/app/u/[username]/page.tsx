import { notFound } from "next/navigation";
import Profile from "./Profile";
import { getProfile, profiles } from "@/lib/data";

export function generateStaticParams() {
  return profiles.map((p) => ({ username: p.username }));
}

export default async function Page({ params }: { params: Promise<{ username: string }> }) {
  const { username } = await params;
  if (!getProfile(username)) notFound();
  return <Profile username={username} />;
}

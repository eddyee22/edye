"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { TopBar } from "@/components/ui";
import { CURRENT_USER, type Guide, type Subject } from "@/lib/data";
import { useStore } from "@/lib/store";

const KINDS: Guide["kind"][] = ["Study guide", "Cheat sheet", "Practice set", "Anki deck"];
const SUBJECTS: [Subject, string][] = [["cs", "Computer science"], ["math", "Math"], ["bio", "Biology"], ["chem", "Chemistry"], ["econ", "Economics"], ["psych", "Psych / Cog Sci"], ["hist", "Humanities"], ["piq", "PIQ / college apps"]];

export default function Create() {
  const router = useRouter();
  const { postGuide } = useStore();
  const [form, setForm] = useState({ course: "", title: "", kind: KINDS[0], subject: "cs" as Subject, pages: "", price: "", caption: "", contents: "" });
  const [original, setOriginal] = useState(false);
  const set = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => setForm({ ...form, [k]: e.target.value });

  const price = Number(form.price);
  const ready = form.course.trim() && form.title.trim() && Number(form.pages) > 0 && price >= 1 && original;

  function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!ready) return;
    postGuide({
      id: Date.now(),
      seller: CURRENT_USER,
      course: form.course.trim().toUpperCase(),
      title: form.title.trim(),
      kind: form.kind,
      subject: form.subject,
      pages: Number(form.pages),
      priceCents: Math.round(price * 100),
      likes: 0,
      sold: 0,
      caption: form.caption.trim() || undefined,
      postedAt: new Date().toISOString(),
      contents: form.contents.split("\n").map((s) => s.trim()).filter(Boolean),
    });
    router.push(`/u/${CURRENT_USER}`);
  }

  return (
    <>
      <TopBar title="Sell a study guide" />
      <form className="page" onSubmit={submit}>
        <label className="lbl" htmlFor="course">Class</label>
        <input id="course" className="field" placeholder="CS 61A" value={form.course} onChange={set("course")} />
        <label className="lbl" htmlFor="title">Title</label>
        <input id="title" className="field" placeholder="Recursion & Trees, Midterm 2" value={form.title} onChange={set("title")} />
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
          <div>
            <label className="lbl" htmlFor="kind">Type</label>
            <select id="kind" className="field" value={form.kind} onChange={set("kind")}>{KINDS.map((k) => <option key={k}>{k}</option>)}</select>
          </div>
          <div>
            <label className="lbl" htmlFor="subject">Subject</label>
            <select id="subject" className="field" value={form.subject} onChange={set("subject")}>{SUBJECTS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select>
          </div>
          <div>
            <label className="lbl" htmlFor="pages">{form.kind === "Anki deck" ? "Cards" : "Pages"}</label>
            <input id="pages" className="field" inputMode="numeric" placeholder="12" value={form.pages} onChange={set("pages")} />
          </div>
          <div>
            <label className="lbl" htmlFor="price">Price ($)</label>
            <input id="price" className="field" inputMode="decimal" placeholder="6" value={form.price} onChange={set("price")} />
          </div>
        </div>
        <label className="lbl" htmlFor="contents">What&apos;s inside (one per line)</label>
        <textarea id="contents" className="field" rows={3} placeholder={"Practice problems\nOne-page summary"} value={form.contents} onChange={set("contents")} />
        <label className="lbl" htmlFor="caption">Caption</label>
        <textarea id="caption" className="field" rows={2} placeholder="What makes this guide useful?" value={form.caption} onChange={set("caption")} />
        <label className="lbl" htmlFor="file">File</label>
        <input id="file" type="file" accept=".pdf,.apkg" className="field" />
        <label style={{ display: "flex", gap: 10, alignItems: "flex-start", margin: "18px 0", lineHeight: 1.4 }}>
          <input id="original" type="checkbox" checked={original} onChange={(e) => setOriginal(e.target.checked)} style={{ marginTop: 3 }} />
          <span>This is my own original work. It isn&apos;t copied lecture notes, professor slides or exams.</span>
        </label>
        <button className="btn block" disabled={!ready}>Post guide</button>
      </form>
    </>
  );
}

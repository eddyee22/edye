"use client";

import Link from "next/link";
import { useState } from "react";
import { Avatar, TopBar, Verified } from "@/components/ui";
import { CURRENT_USER, getProfile, money, offerings, subjectGradient, type OfferingCategory } from "@/lib/data";
import { useStore } from "@/lib/store";

const TABS: [OfferingCategory, string][] = [["tutoring", "Tutoring"], ["advising", "Advising"], ["piq", "PIQ help"]];

const INTRO: Record<OfferingCategory, [string, string, string]> = {
  tutoring: [subjectGradient.cs, "One-on-one tutoring", "Book a student who aced the class you're in. Cancel up to 12 hours before."],
  advising: [subjectGradient.adv, "Advising meetings", "Plan your major, check requirements, or map a transfer path."],
  piq: [subjectGradient.piq, "PIQ coaching for high schoolers", "Work with UC students on your Personal Insight Questions: 4 of 8 prompts, 350 words each."],
};

export default function Sessions() {
  const [tab, setTab] = useState<OfferingCategory>("tutoring");
  const { bookings } = useStore();
  const upcoming = bookings.filter((b) => new Date(b.startsAt) > new Date());
  const [bg, title, text] = INTRO[tab];

  return (
    <>
      <TopBar title="Sessions" />
      <div className="sec">Upcoming <small>{upcoming.length} booked</small></div>
      {upcoming.length === 0 && <div className="empty" style={{ marginTop: 0 }}>No sessions yet. Pick someone below to book your first one.</div>}
      {upcoming.map((b) => {
        const d = new Date(b.startsAt);
        return (
          <div key={b.id} className="card">
            <div className="datebox"><small>{d.toLocaleDateString("en-US", { weekday: "short" })}</small><b>{d.getDate()}</b></div>
            <div className="who">
              <b>{b.session} with {getProfile(b.provider)?.name}</b>
              <small>{d.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" })} · {b.where}</small>
            </div>
          </div>
        );
      })}
      <div className="seg">
        {TABS.map(([k, l]) => <button key={k} className={tab === k ? "on" : ""} onClick={() => setTab(k)}>{l}</button>)}
      </div>
      <div className="intro" style={{ background: bg }}><b>{title}</b>{text}</div>
      {offerings.filter((o) => o.category === tab && o.provider !== CURRENT_USER).map((o) => {
        const p = getProfile(o.provider)!;
        return (
          <div key={o.provider} className="prov">
            <Link href={`/u/${p.username}`}><Avatar username={p.username} size={56} ring /></Link>
            <div className="who">
              <b>{p.name}</b>{p.verified && <Verified />}
              <small>{o.topics}</small>
              <small><span className="stars">★</span> {o.rating.toFixed(1)} · {o.reviews} reviews · <b>from {money(Math.min(...o.sessions.map((s) => s.priceCents)))}</b></small>
            </div>
            <Link className="btn" href={`/book/${p.username}`}>Book</Link>
          </div>
        );
      })}
    </>
  );
}

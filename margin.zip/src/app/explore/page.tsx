"use client";

import Link from "next/link";
import { useState } from "react";
import { Avatar, Cover, Icon, TopBar } from "@/components/ui";
import { CURRENT_USER, getProfile, guides, money, offerings, subjectGradient, type Guide, type Offering } from "@/lib/data";

const FILTERS = ["All", "Study guides", "Anki decks", "Tutors", "Advising", "PIQ help"] as const;
type Filter = (typeof FILTERS)[number];

type Item = { type: "guide"; g: Guide } | { type: "person"; o: Offering };

export default function Explore() {
  const [filter, setFilter] = useState<Filter>("All");
  const [q, setQ] = useState("");

  const guideItems: Item[] = guides
    .filter((g) => g.seller !== CURRENT_USER)
    .filter((g) =>
      filter === "All" || (filter === "Study guides" && g.kind !== "Anki deck") ||
      (filter === "Anki decks" && g.kind === "Anki deck") || (filter === "PIQ help" && g.subject === "piq"))
    .map((g) => ({ type: "guide", g }));
  const personItems: Item[] = offerings
    .filter((o) => o.provider !== CURRENT_USER)
    .filter((o) =>
      filter === "All" || (filter === "Tutors" && o.category === "tutoring") ||
      (filter === "Advising" && o.category === "advising") || (filter === "PIQ help" && o.category === "piq"))
    .map((o) => ({ type: "person", o }));

  const needle = q.trim().toLowerCase();
  const items = [...guideItems, ...personItems].filter((i) =>
    !needle || (i.type === "guide"
      ? `${i.g.course} ${i.g.title}`
      : `${getProfile(i.o.provider)?.name} ${i.o.provider} ${i.o.topics}`).toLowerCase().includes(needle));

  return (
    <>
      <TopBar title="Explore" />
      <label className="search">
        <Icon name="search" size={18} />
        <input id="q" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search classes, tutors, schools" autoComplete="off" />
      </label>
      <div className="chips">
        {FILTERS.map((f) => (
          <button key={f} className={`chip${filter === f ? " on" : ""}`} onClick={() => setFilter(f)}>{f}</button>
        ))}
      </div>
      {items.length === 0 ? (
        <div className="empty">Nothing matches &quot;{q}&quot;. Try a class code like CS 61A.</div>
      ) : (
        <div className="grid">
          {items.map((i) => i.type === "guide" ? (
            <Link key={`g${i.g.id}`} href={`/guides/${i.g.id}`}><Cover guide={i.g} small /></Link>
          ) : (
            <Link key={`p${i.o.provider}`} href={`/book/${i.o.provider}`} className="cover small"
              style={{ background: subjectGradient[i.o.category === "piq" ? "piq" : i.o.category === "advising" ? "adv" : "bio"], alignItems: "center", justifyContent: "center", textAlign: "center", gap: 6 }}>
              <div className="price">{money(Math.min(...i.o.sessions.map((s) => s.priceCents)))}</div>
              <Avatar username={i.o.provider} size={34} />
              <div className="ttl">{getProfile(i.o.provider)?.name}</div>
              <div className="code">{i.o.category === "piq" ? "PIQ coach" : i.o.category === "advising" ? "Advising" : "Tutor"}</div>
            </Link>
          ))}
        </div>
      )}
    </>
  );
}

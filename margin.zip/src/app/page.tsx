import Link from "next/link";
import PostCard from "@/components/PostCard";
import { Avatar } from "@/components/ui";
import { CURRENT_USER, guides, offerings } from "@/lib/data";

const roleLabel = { tutoring: "Tutor", advising: "Advising", piq: "PIQ coach" } as const;

export default function Home() {
  const feed = guides.filter((g) => g.caption).sort((a, b) => b.postedAt.localeCompare(a.postedAt));
  const stories = offerings.filter((o) => o.provider !== CURRENT_USER);

  return (
    <>
      <header className="top">
        <div className="wordmark">Margin</div>
      </header>
      <div className="stories">
        <Link href="/create" className="story">
          <Avatar username={CURRENT_USER} size={62} />
          <span>Your story</span>
        </Link>
        {stories.map((o) => (
          <Link key={o.provider} href={`/book/${o.provider}`} className="story">
            <Avatar username={o.provider} size={62} ring />
            <span>{o.provider}</span>
            <small>{roleLabel[o.category]}</small>
          </Link>
        ))}
      </div>
      {feed.map((g) => <PostCard key={g.id} guide={g} />)}
      <div className="empty">You&apos;re all caught up.</div>
    </>
  );
}

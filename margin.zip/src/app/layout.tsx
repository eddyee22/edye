import type { Metadata, Viewport } from "next";
import { Grand_Hotel } from "next/font/google";
import "./globals.css";
import TabBar from "@/components/TabBar";
import { StoreProvider } from "@/lib/store";

const script = Grand_Hotel({ weight: "400", subsets: ["latin"], variable: "--font-script" });

export const metadata: Metadata = {
  title: "Margin",
  description: "Study guides, tutoring, advising and PIQ coaching from students who've been there.",
};

export const viewport: Viewport = { width: "device-width", initialScale: 1, viewportFit: "cover" };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={script.variable}>
      <body>
        <StoreProvider>
          <div className="app">{children}</div>
          <TabBar />
        </StoreProvider>
      </body>
    </html>
  );
}

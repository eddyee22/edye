"use client";

import Link from "next/link";
import { useState } from "react";
import { Avatar, Cover, Icon, TopBar, Verified } from "@/components/ui";
import { CURRENT_USER, compact, getGuide, getProfile, money, offeringsBy } from "@/lib/data";
import { useStore } from "@/lib/store";

export default function GuideDetail({ id }: { id: number }) {
  const { myGuides, purchased, purchase } = useStore();
  const guide = getGuide(id) ?? myGuides.find((g) => g.id === id);
  const [justBought, setJustBought] = useState(false);

  if (!guide) return (<><TopBar title="Guide" /><div className="empty">This guide isn&apos;t available.</div></>);

  const seller = getProfile(guide.seller)!;
  const own = guide.seller === CURRENT_USER;
  const owned = purchased.includes(guide.id);
  const tutors = offeringsBy(guide.seller).length > 0;

  if (justBought) return (
    <div className="success">
      <div className="check">✓</div>
      <h2>It&apos;s yours</h2>
      <p>{guide.title} is in your library.<br />Payments aren&apos;t connected yet, so nothing was charged.</p>
      {tutors && <Link className="btn block" href={`/book/${seller.username}`}>Book a session with {seller.name.split(" ")[0]}</Link>}
      <p><Link href="/" className="tag">Back to feed</Link></p>
    </div>
  );

  return (
    <>
      <TopBar title={guide.course}><Link href="/" aria-label="Back"><Icon name="back" /></Link></TopBar>
      <Cover guide={guide} />
      <div className="page">
        <h2 style={{ margin: "14px 0 4px", fontSize: 20 }}>{guide.title}</h2>
        <div style={{ color: "var(--muted)" }}>{guide.kind} · {guide.pages} {guide.kind === "Anki deck" ? "cards" : "pages"} · {compact(guide.sold)} sold</div>

        <Link href={`/u/${seller.username}`} className="card" style={{ margin: "16px 0 0" }}>
          <Avatar username={seller.username} size={40} />
          <div className="who"><b>{seller.name}</b>{seller.verified && <Verified />}<small>{seller.school}</small></div>
        </Link>

        <span className="lbl">What&apos;s inside</span>
        <ul style={{ margin: 0, paddingLeft: 18, lineHeight: 1.8 }}>
          {guide.contents.map((c) => <li key={c}>{c}</li>)}
        </ul>
        <p style={{ color: "var(--muted)", fontSize: 12.5 }}>Original work by the seller. Report it if it copies lecture notes, slides or exams.</p>

        <div className="sumrow"><span>Price</span><b>{money(guide.priceCents)}</b></div>
        {own ? <span className="btn ghost block">This is your guide</span>
          : owned ? <span className="btn done block">In your library</span>
          : <button className="btn block" onClick={() => { purchase(guide.id); setJustBought(true); }}>Buy for {money(guide.priceCents)}</button>}
      </div>
    </>
  );
}

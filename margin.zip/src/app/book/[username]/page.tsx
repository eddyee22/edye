import { notFound } from "next/navigation";
import Booking from "./Booking";
import { offeringsBy } from "@/lib/data";

export default async function Page({ params }: { params: Promise<{ username: string }> }) {
  const { username } = await params;
  if (offeringsBy(username).length === 0) notFound();
  return <Booking username={username} />;
}

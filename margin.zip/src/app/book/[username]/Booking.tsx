"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { Avatar, Icon, TopBar, Verified } from "@/components/ui";
import { getProfile, money, offeringsBy } from "@/lib/data";
import { useStore } from "@/lib/store";

const TIMES = ["10:00", "11:30", "13:00", "15:00", "16:30", "19:00"];
const label = (t: string) => {
  const [h, m] = t.split(":").map(Number);
  return `${((h + 11) % 12) + 1}:${String(m).padStart(2, "0")} ${h < 12 ? "AM" : "PM"}`;
};

export default function Booking({ username }: { username: string }) {
  const p = getProfile(username)!;
  const offer = offeringsBy(username)[0];
  const { bookings, book } = useStore();

  const days = useMemo(() => {
    const start = new Date();
    start.setHours(0, 0, 0, 0);
    return Array.from({ length: 10 }, (_, i) => { const d = new Date(start); d.setDate(d.getDate() + i + 1); return d; });
  }, []);

  const [kind, setKind] = useState(0);
  const [day, setDay] = useState(0);
  const [time, setTime] = useState<string | null>(null);
  const [done, setDone] = useState<Date | null>(null);
  // Dates depend on the viewer's timezone, so render on the client only.
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  const startsAt = (t: string) => { const d = new Date(days[day]); const [h, m] = t.split(":").map(Number); d.setHours(h, m); return d; };
  // Until real availability exists: a slot is taken if it's already booked here, or by a simple stand-in pattern.
  const taken = (t: string, i: number) =>
    (i + day * 2) % 5 === 0 || bookings.some((b) => b.provider === username && b.startsAt === startsAt(t).toISOString());

  const session = offer.sessions[kind];
  if (!mounted) return null;

  if (done) return (
    <div className="success">
      <div className="check">✓</div>
      <h2>You&apos;re booked</h2>
      <p>{session.name} with {p.name}<br />
        {done.toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" })} at {done.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" })}<br />
        {offer.where}</p>
      <Link className="btn block" href="/sessions">See my sessions</Link>
    </div>
  );

  return (
    <>
      <TopBar title="Book a session"><Link href={`/u/${username}`} aria-label="Back"><Icon name="back" /></Link></TopBar>
      <div className="page">
        <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
          <Avatar username={username} size={56} ring />
          <div className="who">
            <b>{p.name}</b>{p.verified && <Verified />}
            <small>{offer.topics}</small>
            <small><span className="stars">★</span> {offer.rating.toFixed(1)} · {offer.reviews} reviews · {offer.where}</small>
          </div>
        </div>

        <span className="lbl">Session</span>
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {offer.sessions.map((s, i) => (
            <button key={s.name} className={`opt${kind === i ? " on" : ""}`} onClick={() => setKind(i)}>
              <span><b>{s.name}</b><small>{s.minutes >= 120 ? `${s.minutes / 60} hours total` : `${s.minutes} min`}</small></span>
              <b>{money(s.priceCents)}</b>
            </button>
          ))}
        </div>

        <span className="lbl">{days[day].toLocaleDateString("en-US", { month: "long" })}</span>
        <div className="dates">
          {days.map((d, i) => (
            <button key={i} className={`date${day === i ? " on" : ""}`} onClick={() => { setDay(i); setTime(null); }}>
              <small>{d.toLocaleDateString("en-US", { weekday: "short" })}</small><b>{d.getDate()}</b>
            </button>
          ))}
        </div>

        <span className="lbl">Time</span>
        <div className="slots">
          {TIMES.map((t, i) => (
            <button key={t} className={`slot${time === t ? " on" : ""}`} disabled={taken(t, i)} onClick={() => setTime(t)}>{label(t)}</button>
          ))}
        </div>

        <div className="sumrow"><span>{session.name}</span><b>{money(session.priceCents)}</b></div>
        <button className="btn block" disabled={!time} onClick={() => {
          if (!time) return;
          const at = startsAt(time);
          book({ provider: username, session: session.name, startsAt: at.toISOString(), where: offer.where, priceCents: session.priceCents });
          setDone(at);
        }}>
          {time ? `Book ${days[day].toLocaleDateString("en-US", { weekday: "short" })} at ${label(time)}` : "Pick a time"}
        </button>
      </div>
    </>
  );
}

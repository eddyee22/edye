# Margin

A student hub, styled like Instagram, for:

- selling original study guides, cheat sheets, practice sets and Anki decks
- booking one-on-one tutoring
- scheduling advising meetings
- booking PIQ (UC Personal Insight Question) coaches

## Run it

```bash
npm install
npm run dev
```

Open http://localhost:3000 on your phone or in your browser's mobile view.

## What works today

| Screen | Path | What it does |
| --- | --- | --- |
| Feed | `/` | Study guide posts, like, save, share; tutor and coach stories |
| Explore | `/explore` | Search and filter guides, Anki decks, tutors, advising, PIQ help |
| Guide | `/guides/[id]` | Details, what's inside, buy |
| Book | `/book/[username]` | Pick a session type, date and time |
| Sessions | `/sessions` | Your upcoming bookings and everyone you can book |
| Profile | `/u/[username]` | Portfolio grid of guides, reviews |
| Sell | `/create` | Post a guide, with the original-work checkbox |

Right now the app runs on sample data (`src/lib/data.ts`), and your likes, purchases, bookings and posted guides are saved in your browser only (`src/lib/store.tsx`). Nothing is charged.

## Next steps

1. **Accounts and database.** Create a free Supabase project, run `supabase/schema.sql`, and swap the sample data for Supabase queries.
2. **File uploads.** Store guide PDFs and Anki decks in a private Supabase Storage bucket, with a free preview page.
3. **Payments.** Stripe Connect so sellers and tutors get paid out and Margin keeps a platform fee.
4. **Real availability.** Tutors set weekly hours, and booked slots disappear for everyone.
5. **Moderation.** New guides start as `pending_review`, plus a report button.
6. **Deploy.** Vercel (free tier) gives you a link anyone can open on their phone.
